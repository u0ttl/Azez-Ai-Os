# Azez AI OS

An Arabic-first, multi-tenant business operating platform with governed AI assistance.

## Current milestone

Distributed-security release (`0.11.0`): Redis-backed atomic rate limits across API replicas, global and authentication-specific throttles, ClamAV INSTREAM scanning with production fail-closed behavior, dependency-aware readiness, plus the complete platform-readiness and business layers from earlier releases.

## Requirements

- Node.js 24 LTS
- pnpm 11+
- Docker Desktop (for PostgreSQL, Redis, MinIO, and production ClamAV)

## Start locally

```bash
cp .env.example .env
pnpm install
docker compose up -d
pnpm db:generate
pnpm db:migrate
pnpm dev
```

To exercise external malware scanning locally, set `CLAMAV_HOST=localhost` and run `docker compose --profile security up -d`.

- Web: http://localhost:3000
- API: http://localhost:4000/v1
- Health: http://localhost:4000/v1/health
- Readiness: http://localhost:4000/v1/health/ready
- OpenAPI: http://localhost:4000/docs
- Metrics: http://localhost:4000/v1/metrics

To load the optional demo account and sample CRM/project data after migrations:

```bash
ALLOW_DEMO_SEED=true pnpm db:seed
```

See `docs/OPERATIONS.md` for production Compose, probes, smoke E2E, backup, restore, and rollback guidance.

## Foundation API

- `GET /v1/auth/csrf` issues the signed double-submit token required by every mutating request.
- `POST /v1/auth/register` creates a user, owned organization, membership, email-verification outbox item, audit event, and HttpOnly session.
- `POST /v1/auth/login` starts a secure server-side session.
- `GET /v1/auth/me` returns the authenticated identity and memberships.
- `POST /v1/auth/logout` revokes the current session.
- `GET /v1/auth/sessions` lists active devices; `DELETE /v1/auth/sessions/:id` revokes one.
- `POST /v1/auth/logout-all` revokes every active session.
- `POST /v1/auth/change-password` changes the password and revokes other sessions.
- `POST /v1/auth/forgot-password` and `POST /v1/auth/reset-password` use expiring, single-use tokens without revealing whether an email exists.
- `POST /v1/auth/verify-email` and `POST /v1/auth/resend-verification` manage email ownership verification.
- `/v1/organizations` is authenticated and only returns organizations belonging to the current user.
- `/v1/organizations/:organizationId/crm/companies` lists and creates tenant-scoped companies.
- `/v1/organizations/:organizationId/crm/companies/:companyId` returns the full company profile with contacts, activities, and opportunities.
- `/v1/organizations/:organizationId/crm/companies/:companyId/contacts` adds company contacts.
- `/v1/organizations/:organizationId/crm/companies/:companyId/activities` records notes, calls, emails, meetings, and follow-ups.
- `/v1/organizations/:organizationId/crm/leads` lists, creates, and advances sales opportunities.
- `/v1/organizations/:organizationId/projects` lists and creates projects.
- `/v1/organizations/:organizationId/projects/:projectId` returns the project, members, assignees, and Kanban tasks.
- `/v1/organizations/:organizationId/projects/available-assignees` lists active organization members eligible for assignment.
- `/v1/organizations/:organizationId/projects/:projectId/members` adds or updates a project member.
- `/v1/organizations/:organizationId/projects/:projectId/tasks` lists, creates, and updates tasks.
- `/v1/organizations/:organizationId/projects/:projectId/tasks/:taskId/comments` lists and adds task discussion.
- `/v1/organizations/:organizationId/projects/:projectId/tasks/:taskId/attachments` uploads and lists protected task files.
- `/v1/organizations/:organizationId/projects/:projectId/tasks/:taskId/attachments/:attachmentId/download` returns a five-minute signed download URL.
- `/v1/notifications` lists the authenticated user's assignment and comment notifications.
- `/v1/notifications/unread-count`, `/v1/notifications/:id/read`, and `/v1/notifications/read-all` manage read state.
- `/v1/organizations/:organizationId/knowledge/bases` manages knowledge collections.
- `/v1/organizations/:organizationId/knowledge/bases/:baseId/documents/text` ingests and chunks text documents.
- `/v1/organizations/:organizationId/knowledge/bases/:baseId/search` performs Arabic-aware local retrieval.
- `/v1/organizations/:organizationId/ai/conversations` creates conversations and stores cited answers and usage.
- `/v1/organizations/:organizationId/workflows` manages version-ready workflow definitions and allowlisted steps.
- `/v1/organizations/:organizationId/workflows/:workflowId/runs` executes active manual workflows.
- `/v1/organizations/:organizationId/workflows/approvals/pending` lists human approval gates.
- `/v1/organizations/:organizationId/workflows/approvals/:approvalId/decision` approves or rejects a waiting run.
- `/v1/organizations/:organizationId/billing/plans` lists product plans and entitlements.
- `/v1/organizations/:organizationId/billing/summary` returns the active subscription, limits, and current usage.
- `/v1/organizations/:organizationId/billing/select-plan` currently permits only the internal free plan for owners/admins.

Paid checkout is intentionally disabled until a payment provider, supported countries, currencies, tax responsibilities, pricing, and webhook signing policy are approved. Growth and Enterprise are product placeholders without fabricated prices.

The default AI implementation is private local retrieval (`local-retrieval/extractive-v1`). It does not send organization data to an external model. OpenAI responses and embeddings are available only after explicit server-side configuration and remain behind usage limits and fallback policy.

## Optional OpenAI mode

Local retrieval remains the default. To intentionally enable the external provider:

```env
AI_PROVIDER=openai
OPENAI_API_KEY=replace-with-a-project-key
OPENAI_MODEL=gpt-5.6
EMBEDDINGS_ENABLED=true
OPENAI_EMBEDDING_MODEL=text-embedding-3-small
AI_DAILY_REQUEST_LIMIT=100
```

The server uses the Responses API with remote response storage disabled, tracks organization usage, enforces a daily request limit, and falls back to local retrieval during provider failure. Never expose the API key through `NEXT_PUBLIC_*` variables or commit it to Git.

## Safety

Development credentials are placeholders. Never commit a populated `.env`. AI providers are disabled until a key and an explicit provider selection are supplied.

Account emails are transactionally written to `email_outbox`. When `SMTP_HOST` is configured, the built-in worker claims and sends them with exponential retry and a five-attempt failure limit. Keep `REQUIRE_EMAIL_VERIFICATION=false` until SMTP delivery has been tested. Redis-backed atomic limits protect authentication and the wider API across replicas; production fails closed if Redis is unavailable. See `docs/SECURITY.md` and `docs/FILES.md`.

## Secure attachments

MinIO is created by Docker Compose with a private `azez-ai-os` bucket. Accepted uploads are PDF, DOCX, TXT, PNG, and JPEG up to 10 MB by default. The API validates type and signatures, then streams the bytes to ClamAV before storage when configured. Production Compose requires ClamAV and refuses uploads if scanning is unavailable. Downloads use private signed URLs valid for five minutes.
