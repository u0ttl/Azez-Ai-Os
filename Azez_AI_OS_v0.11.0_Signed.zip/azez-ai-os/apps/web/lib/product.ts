export const product = {
  name: "Azez AI OS",
  locale: "ar",
  direction: "rtl",
} as const;
